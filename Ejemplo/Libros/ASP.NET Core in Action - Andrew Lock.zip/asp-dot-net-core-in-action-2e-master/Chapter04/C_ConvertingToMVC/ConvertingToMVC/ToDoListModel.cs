﻿namespace ConvertingToMVC
{
    public class ToDoListModel
    {
        public string Title { get; set; }

        public string Category { get; set; }
    }
}