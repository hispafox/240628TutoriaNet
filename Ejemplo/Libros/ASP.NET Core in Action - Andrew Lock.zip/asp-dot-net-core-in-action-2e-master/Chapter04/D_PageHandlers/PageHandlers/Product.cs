﻿namespace PageHandlers
{
    public class Product
    {
        public string Name { get; set; }
    }
}
